import type { Config } from 'tailwindcss';

// Palette: indigo-dyed cloth, marigold thread, undyed paper. Deliberately not the usual cream/terracotta.
export default {
  content: ['./index.html', './admin.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAF8F5',
        indigo: { DEFAULT: '#1F2A4A', soft: '#3A4670', tint: '#E8EAF2' },
        marigold: { DEFAULT: '#E3A21A', deep: '#A87100' },
        sage: '#3F6B63',
        madder: '#A8322D',
        ink: '#191B22',
      },
      fontFamily: {
        display: ['"Young Serif"', 'Georgia', 'serif'],
        sans: ['Figtree', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [],
} satisfies Config;
