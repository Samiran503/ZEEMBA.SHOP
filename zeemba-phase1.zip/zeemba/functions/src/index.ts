import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { onObjectFinalized } from 'firebase-functions/v2/storage';
import { defineString } from 'firebase-functions/params';
import { logger, setGlobalOptions } from 'firebase-functions/v2';
import { writeAuditLog } from './lib/audit';
import { invalidatePermissionCache, requireAuth, requirePermission } from './lib/guard';
import { DEFAULT_ROLE_PERMISSIONS, NON_DELEGABLE, PERMISSIONS, ROLES, type Permission, type Role } from './lib/permissions';
import { rateLimit } from './lib/rateLimit';

initializeApp();
// Keep functions near Indian users. Firestore/Storage buckets should be created in the same region (asia-south1).
setGlobalOptions({ region: 'asia-south1', maxInstances: 20 });

const db = getFirestore();
// App Check is enforced on every callable in deployed environments (disabled only in the local emulator).
const enforceAppCheck = process.env.FUNCTIONS_EMULATOR !== 'true';
const BOOTSTRAP_ADMIN_EMAIL = defineString('BOOTSTRAP_ADMIN_EMAIL', { default: '' });

/**
 * One-time bootstrap of the first SUPER_ADMIN. No credentials exist in code:
 *  - caller must be signed in with a VERIFIED email equal to the BOOTSTRAP_ADMIN_EMAIL deploy parameter
 *  - a transactional lock (settings/security.bootstrapped) makes it impossible to run twice
 *  - after use, remove the parameter and redeploy.
 */
export const bootstrapSuperAdmin = onCall({ enforceAppCheck }, async (req) => {
  const uid = requireAuth(req);
  const email = String(req.auth?.token.email ?? '').toLowerCase();
  const allowed = BOOTSTRAP_ADMIN_EMAIL.value().trim().toLowerCase();
  await rateLimit(`bootstrap:${uid}`, 5, 3600);
  if (!allowed || email !== allowed || req.auth?.token.email_verified !== true) {
    logger.warn('bootstrapSuperAdmin denied', { uid });
    throw new HttpsError('permission-denied', 'Not permitted.');
  }

  const lock = db.doc('settings/security');
  await db.runTransaction(async (tx) => {
    const s = await tx.get(lock);
    if (s.exists && s.get('bootstrapped') === true) throw new HttpsError('failed-precondition', 'Already initialised.');
    tx.set(lock, { bootstrapped: true, bootstrappedBy: uid, bootstrappedAt: FieldValue.serverTimestamp() });
    tx.set(db.doc(`staff/${uid}`), { role: 'SUPER_ADMIN', active: true, email, createdBy: uid, createdAt: FieldValue.serverTimestamp() });
    const rp = db.doc('settings/rolePermissions');
    if (!(await tx.get(rp)).exists) tx.set(rp, DEFAULT_ROLE_PERMISSIONS);
  });

  await getAuth().setCustomUserClaims(uid, { role: 'SUPER_ADMIN' });
  await writeAuditLog({ adminUid: uid, role: 'SUPER_ADMIN', action: 'SUPER_ADMIN_BOOTSTRAP', target: { type: 'user', id: uid } });
  return { ok: true, next: 'Sign out and sign in again to receive your new role.' };
});

/** SUPER_ADMIN only: assign/remove a staff role. Never self-service; cannot remove the last SUPER_ADMIN. */
export const setStaffRole = onCall({ enforceAppCheck }, async (req) => {
  const actor = await requirePermission(req, 'staff.manage');
  await rateLimit(`setStaffRole:${actor.uid}`, 30, 3600);

  const { targetUid, role } = (req.data ?? {}) as { targetUid?: string; role?: Role | null };
  if (typeof targetUid !== 'string' || targetUid.length < 6 || targetUid.length > 128) throw new HttpsError('invalid-argument', 'Invalid user.');
  if (role !== null && !ROLES.includes(role as Role)) throw new HttpsError('invalid-argument', 'Invalid role.');
  if (targetUid === actor.uid) throw new HttpsError('failed-precondition', 'You cannot change your own role.');

  const target = await getAuth().getUser(targetUid).catch(() => null);
  if (!target) throw new HttpsError('not-found', 'User not found.');
  if (role && !target.email) throw new HttpsError('failed-precondition', 'Staff accounts need an email address.');

  const staffRef = db.doc(`staff/${targetUid}`);
  await db.runTransaction(async (tx) => {
    const current = await tx.get(staffRef);
    if (current.exists && current.get('role') === 'SUPER_ADMIN' && current.get('active') === true && role !== 'SUPER_ADMIN') {
      const supers = await tx.get(db.collection('staff').where('role', '==', 'SUPER_ADMIN').where('active', '==', true).limit(2));
      if (supers.size <= 1) throw new HttpsError('failed-precondition', 'Cannot remove the last super admin.');
    }
    if (role) {
      tx.set(staffRef, { role, active: true, email: target.email ?? null, updatedBy: actor.uid, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    } else {
      tx.set(staffRef, { active: false, updatedBy: actor.uid, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    }
  });

  await getAuth().setCustomUserClaims(targetUid, role ? { role } : {});
  await getAuth().revokeRefreshTokens(targetUid); // forces re-login so stale tokens stop working
  await writeAuditLog({
    adminUid: actor.uid, role: actor.role, action: 'ROLE_CHANGE',
    target: { type: 'user', id: targetUid }, metadata: { newRole: role ?? 'REMOVED' },
  });
  return { ok: true };
});

/** SUPER_ADMIN only: edit which permissions ADMIN / STAFF hold. Enforced by functions AND Firestore rules. */
export const updateRolePermissions = onCall({ enforceAppCheck }, async (req) => {
  const actor = await requirePermission(req, 'staff.manage');
  const { role, permissions } = (req.data ?? {}) as { role?: string; permissions?: string[] };
  if (role !== 'ADMIN' && role !== 'STAFF') throw new HttpsError('invalid-argument', 'Invalid role.');
  if (!Array.isArray(permissions) || permissions.length > PERMISSIONS.length) throw new HttpsError('invalid-argument', 'Invalid permissions.');
  const clean = [...new Set(permissions)];
  for (const p of clean) {
    if (!PERMISSIONS.includes(p as Permission) || NON_DELEGABLE.includes(p as Permission)) {
      throw new HttpsError('invalid-argument', `Permission not allowed: ${String(p).slice(0, 40)}`);
    }
  }
  await db.doc('settings/rolePermissions').set({ [role]: clean }, { merge: true });
  invalidatePermissionCache();
  await writeAuditLog({ adminUid: actor.uid, role: actor.role, action: 'ROLE_PERMISSIONS_UPDATE', target: { type: 'role', id: role }, metadata: { permissions: clean } });
  return { ok: true };
});

/** Called by the admin app after sign-in so logins appear in the audit trail. */
export const recordAdminLogin = onCall({ enforceAppCheck }, async (req) => {
  const uid = requireAuth(req);
  const role = req.auth?.token.role as Role | undefined;
  if (!role || !ROLES.includes(role)) throw new HttpsError('permission-denied', 'You do not have access.');
  await rateLimit(`adminLogin:${uid}`, 20, 3600);
  await writeAuditLog({ adminUid: uid, role, action: 'ADMIN_LOGIN' });
  return { ok: true };
});

// ---------------------------------------------------------------------------
// Upload hardening: Storage rules cannot read file bytes. This trigger verifies the real
// image signature (magic bytes), deletes impostors, and marks genuine files as validated.
// ---------------------------------------------------------------------------
const PROTECTED_PREFIXES = ['orderUploads/', 'customUploads/', 'reviewImages/', 'products/', 'homepage/'];

function detectImageType(b: Buffer): 'jpeg' | 'png' | 'webp' | null {
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpeg';
  if (b.length >= 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (b.length >= 12 && b.subarray(0, 4).toString('ascii') === 'RIFF' && b.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  return null;
}

export const validateUploadedImage = onObjectFinalized({ memory: '256MiB' }, async (event) => {
  const { name, bucket } = event.data;
  if (!name || !PROTECTED_PREFIXES.some((p) => name.startsWith(p))) return;
  const file = getStorage().bucket(bucket).file(name);
  const [head] = await file.download({ start: 0, end: 11 });
  const kind = detectImageType(head);
  if (!kind) {
    logger.warn('Rejected non-image upload', { name });
    await file.delete({ ignoreNotFound: true });
    return;
  }
  await file.setMetadata({ metadata: { validated: 'true', detectedType: kind } });
});
