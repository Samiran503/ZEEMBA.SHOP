export const ROLES = ['SUPER_ADMIN', 'ADMIN', 'STAFF'] as const;
export type Role = (typeof ROLES)[number];
export type ConfigurableRole = Exclude<Role, 'SUPER_ADMIN'>;

export const PERMISSIONS = [
  'products.read', 'products.write',
  'orders.read', 'orders.write',
  'customers.read',
  'inventory.read', 'inventory.write',
  'coupons.read', 'coupons.write',
  'homepage.write',
  'reviews.moderate',
  'customOrders.read', 'customOrders.write',
  'analytics.read',
  'exports.run',
  'logs.read',
  'staff.manage',
] as const;
export type Permission = (typeof PERMISSIONS)[number];

// SUPER_ADMIN implicitly has everything. `staff.manage` can never be granted to other roles.
export const NON_DELEGABLE: Permission[] = ['staff.manage'];

export const DEFAULT_ROLE_PERMISSIONS: Record<ConfigurableRole, Permission[]> = {
  ADMIN: [
    'products.read', 'products.write', 'orders.read', 'orders.write', 'customers.read',
    'inventory.read', 'inventory.write', 'coupons.read', 'coupons.write', 'homepage.write',
    'reviews.moderate', 'customOrders.read', 'customOrders.write', 'analytics.read', 'exports.run',
  ],
  STAFF: ['products.read', 'orders.read', 'orders.write', 'inventory.read', 'customOrders.read', 'customOrders.write'],
};
