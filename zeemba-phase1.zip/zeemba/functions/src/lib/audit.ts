import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import type { Role } from './permissions';

const SENSITIVE_KEY = /pass(word)?|secret|token|private|api[-_]?key|authorization|credential|cvv|card/i;

function scrub(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[truncated]';
  if (Array.isArray(value)) return value.slice(0, 50).map((v) => scrub(v, depth + 1));
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([k, v]) => [k, SENSITIVE_KEY.test(k) ? '[redacted]' : scrub(v, depth + 1)]),
    );
  }
  if (typeof value === 'string' && value.length > 500) return value.slice(0, 500) + '…';
  return value;
}

export interface AuditEntry {
  adminUid: string;
  role: Role | string;
  action: string;               // e.g. PRODUCT_CREATE, STOCK_ADJUST, ROLE_CHANGE
  target?: { type: string; id: string };
  metadata?: Record<string, unknown>;
}

/** Append-only audit record. Clients can never write or read-modify this collection (see rules). */
export async function writeAuditLog(entry: AuditEntry): Promise<void> {
  await getFirestore().collection('adminActivityLogs').add({
    adminUid: entry.adminUid,
    role: entry.role,
    action: entry.action,
    target: entry.target ?? null,
    metadata: scrub(entry.metadata ?? {}),
    createdAt: FieldValue.serverTimestamp(),
  });
}
