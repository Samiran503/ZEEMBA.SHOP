import { getFirestore } from 'firebase-admin/firestore';
import { HttpsError, type CallableRequest } from 'firebase-functions/v2/https';
import { DEFAULT_ROLE_PERMISSIONS, ROLES, type Permission, type Role } from './permissions';

let cache: { at: number; data: Record<string, Permission[]> } | null = null;

async function rolePermissions(): Promise<Record<string, Permission[]>> {
  if (cache && Date.now() - cache.at < 30_000) return cache.data;
  const snap = await getFirestore().doc('settings/rolePermissions').get();
  const data = (snap.exists ? snap.data() : DEFAULT_ROLE_PERMISSIONS) as Record<string, Permission[]>;
  cache = { at: Date.now(), data };
  return data;
}
export function invalidatePermissionCache(): void { cache = null; }

export function requireAuth(req: CallableRequest): string {
  if (!req.auth) throw new HttpsError('unauthenticated', 'Please sign in.');
  return req.auth.uid;
}

/**
 * Server-side authorization for every admin callable. Checks, in order:
 *  1. signed in, 2. role claim is a known role, 3. staff registry doc exists AND is active
 *  (so deactivation is effective immediately, not after the ID token expires),
 *  4. the role holds the required permission.
 */
export async function requirePermission(req: CallableRequest, permission: Permission): Promise<{ uid: string; role: Role }> {
  const uid = requireAuth(req);
  const role = req.auth?.token.role as Role | undefined;
  if (!role || !ROLES.includes(role)) throw new HttpsError('permission-denied', 'You do not have access to this action.');

  const staff = await getFirestore().doc(`staff/${uid}`).get();
  if (!staff.exists || staff.get('active') !== true || staff.get('role') !== role) {
    throw new HttpsError('permission-denied', 'You do not have access to this action.');
  }
  if (role !== 'SUPER_ADMIN') {
    const perms = (await rolePermissions())[role] ?? [];
    if (!perms.includes(permission)) throw new HttpsError('permission-denied', 'You do not have access to this action.');
  }
  return { uid, role };
}
