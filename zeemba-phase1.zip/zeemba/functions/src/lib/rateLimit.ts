import { createHash } from 'node:crypto';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { HttpsError } from 'firebase-functions/v2/https';

/** Fixed-window limiter backed by Firestore (collection `rateLimits`, closed to clients by rules). */
export async function rateLimit(key: string, max: number, windowSeconds: number): Promise<void> {
  const db = getFirestore();
  const ref = db.collection('rateLimits').doc(createHash('sha256').update(key).digest('hex'));
  const now = Date.now();
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const d = snap.data() as { count: number; windowStart: number } | undefined;
    if (!d || now - d.windowStart > windowSeconds * 1000) {
      tx.set(ref, { count: 1, windowStart: now, expiresAt: Timestamp.fromMillis(now + windowSeconds * 2000) });
      return;
    }
    if (d.count >= max) throw new HttpsError('resource-exhausted', 'Too many requests. Please try again later.');
    tx.update(ref, { count: d.count + 1 });
  });
}
