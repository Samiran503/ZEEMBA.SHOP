import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'node:path';

// Dev-only: serve admin.html for /admin and /admin/* (Firebase Hosting does this in production).
const adminRewrite = (): Plugin => ({
  name: 'zeemba-admin-rewrite',
  configureServer(server) {
    server.middlewares.use((req, _res, next) => {
      if (req.url && /^\/admin(\/|$|\?)/.test(req.url)) req.url = '/admin.html';
      next();
    });
  },
});

export default defineConfig({
  plugins: [react(), adminRewrite()],
  resolve: { alias: { '@': resolve(__dirname, 'src') } },
  build: {
    target: 'es2020',
    sourcemap: false,
    rollupOptions: {
      // Two separate entry points: customer site and admin app (can be hosted on admin.zeemba.com).
      input: { main: resolve(__dirname, 'index.html'), admin: resolve(__dirname, 'admin.html') },
      output: {
        manualChunks: { firebase: ['firebase/app', 'firebase/auth', 'firebase/firestore', 'firebase/storage', 'firebase/functions'] },
      },
    },
  },
});
