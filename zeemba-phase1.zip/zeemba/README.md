# ZEEMBA: Handmade with Love

Production-oriented e-commerce on React + TypeScript + Tailwind + Firebase.
**Current state: Phase 1 complete** (architecture, security foundation). Phases 2-12 follow.

## Repository map
```
firestore.rules / storage.rules   Deny-by-default security rules (tested in tests/rules)
firestore.indexes.json            Composite indexes for catalog, orders, reviews, logs
firebase.json                     Rules, functions, two hosting targets (web, admin), security headers
functions/src                     Cloud Functions: roles, audit log, rate limiting, upload validation
src/config/site.ts                Brand + the single WhatsApp number constant
src/lib                           firebase init (+App Check), analytics, whatsapp utility
src/types                         Typed data model (money = integer paise)
src/admin                         Separate admin entry point (admin.html), noindex
```

## Setup
1. Create a Firebase project (Blaze plan needed for Cloud Functions). Pick **asia-south1 (Mumbai)** for Firestore, Storage and Functions.
2. Enable: Authentication (Email/Password, Google), Firestore, Storage, App Check (reCAPTCHA Enterprise), Analytics.
3. `cp .env.example .env`, fill public web config. `cp .firebaserc.example .firebaserc`, set project id. Create hosting sites `zeemba-web` and `zeemba-admin`.
4. `npm install && npm --prefix functions install`
5. `npm run dev` (storefront), open `/admin` for the admin shell.
6. Local emulators: `npm run emulators` with `VITE_USE_EMULATORS=true`.

## Security model (defense in depth)
| Layer | What it does |
|---|---|
| Firebase Auth + custom claims | `role` claim (`SUPER_ADMIN`/`ADMIN`/`STAFF`) set only by Cloud Functions |
| Firestore rules | Customers touch only their own profile/cart/wishlist. Orders, reviews, coupons, inventory, analytics, logs, roles are **server-write only** |
| Configurable permissions | `settings/rolePermissions` is read by rules and functions; SUPER_ADMIN edits it via `updateRolePermissions` |
| Cloud Functions | `requirePermission()` re-checks claim, active staff registry entry and permission on every admin action |
| Storage rules | Customer photos are private (owner + staff), create-only, size/type/filename restricted |
| Upload validation | `validateUploadedImage` checks real file signatures and deletes impostors |
| App Check | Enabled client-side; callable functions enforce it when deployed |
| Audit trail | Append-only `adminActivityLogs`; secrets are scrubbed from metadata |
| Rate limiting | Firestore-backed fixed window (`rateLimits`, closed to clients) |
| Headers | HSTS, nosniff, frame protection, Referrer-Policy; CSP in **report-only** until verified |

No admin credentials, private keys or payment secrets exist in this codebase. Payment secrets go in Secret Manager.

### Creating the first SUPER_ADMIN (one time)
1. Sign up on the site with the owner's email and **verify it**.
2. Set the parameter at deploy (`BOOTSTRAP_ADMIN_EMAIL=owner@yourdomain.com`, see `functions/.env.example`) and deploy functions.
3. Call `bootstrapSuperAdmin` from the signed-in app (Phase 7 adds a UI for this).
4. Sign out and in again. **Remove `BOOTSTRAP_ADMIN_EMAIL` and redeploy.** The Firestore lock (`settings/security`) prevents re-running regardless.

## Known limits (be aware)
- Role changes take effect on next token refresh (≤1h). Functions check the staff registry live; Firestore rules rely on the claim, and `revokeRefreshTokens` forces re-login when roles change.
- Storage rules check roles only (not per-permission). Any staff role can read private order uploads.
- CSP is report-only. Review reports, then switch to enforcing.
- Rules tests and functions have **not** been executed in the authoring environment (no network). Run `npm run test:rules` before deploying.
- A web app can't be "unhackable"; this is layered protection, not a guarantee. Run a pre-launch review.

## Backup & recovery
- Enable Firestore **point-in-time recovery** and a **scheduled daily backup** (`gcloud firestore backups schedules create --database='(default)' --recurrence=daily --retention=14w`).
- Enable Storage **soft delete / object versioning** on the bucket.
- The UI only archives (`isArchived`) or soft-deletes; hard deletes are blocked by rules and need a deliberate function.
- Orders store product/price snapshots, so catalog edits never alter history.
- Restore drill: restore backup to a new database, compare, then switch or copy documents. Rehearse before launch.

## Phase checklist
- [x] 1 Architecture, Firebase setup, security foundation
- [ ] 2 Storefront UI &nbsp; [ ] 3 Auth &nbsp; [ ] 4 Products/categories &nbsp; [ ] 5 Product page, wishlist, cart
- [ ] 6 Checkout + orders (Razorpay-ready) &nbsp; [ ] 7 Admin auth + RBAC UI &nbsp; [ ] 8 Admin dashboard
- [ ] 9 Inventory, coupons, CMS &nbsp; [ ] 10 Custom orders + photo upload &nbsp; [ ] 11 Analytics + CSV export
- [ ] 12 Security testing, performance, SEO, deployment
