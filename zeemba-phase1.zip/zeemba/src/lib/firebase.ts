import { initializeApp, type FirebaseApp } from 'firebase/app';
import { initializeAppCheck, ReCaptchaEnterpriseProvider } from 'firebase/app-check';
import { getAuth, connectAuthEmulator, type Auth } from 'firebase/auth';
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, connectFirestoreEmulator, type Firestore } from 'firebase/firestore';
import { getStorage, connectStorageEmulator, type FirebaseStorage } from 'firebase/storage';
import { getFunctions, connectFunctionsEmulator, type Functions } from 'firebase/functions';

// Public web config. It identifies the project; it does NOT grant access. Security Rules + Auth do.
const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
};

export const isFirebaseConfigured = Boolean(config.apiKey && config.projectId && config.appId);
const useEmulators = import.meta.env.VITE_USE_EMULATORS === 'true';
const FUNCTIONS_REGION = 'asia-south1';

export interface FirebaseServices {
  app: FirebaseApp; auth: Auth; db: Firestore; storage: FirebaseStorage; functions: Functions;
}
let cached: FirebaseServices | null = null;

/** Lazily initialises Firebase. Throws a clear error (never a silent failure) if env is not configured. */
export function firebase(): FirebaseServices {
  if (cached) return cached;
  if (!isFirebaseConfigured) {
    throw new Error('Firebase is not configured. Copy .env.example to .env and fill in your project values.');
  }
  const app = initializeApp(config);

  // App Check: blocks traffic that does not come from your real app. Enable enforcement in the Firebase console
  // for Firestore, Storage and Functions once you have confirmed tokens are flowing.
  const siteKey = import.meta.env.VITE_APPCHECK_SITE_KEY;
  if (import.meta.env.DEV) {
    (self as unknown as { FIREBASE_APPCHECK_DEBUG_TOKEN?: string | boolean }).FIREBASE_APPCHECK_DEBUG_TOKEN =
      import.meta.env.VITE_APPCHECK_DEBUG_TOKEN || true;
  }
  if (siteKey && !useEmulators) {
    initializeAppCheck(app, { provider: new ReCaptchaEnterpriseProvider(siteKey), isTokenAutoRefreshEnabled: true });
  }

  const auth = getAuth(app);
  // Offline-capable cache helps on slow/unstable mobile networks.
  const db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) });
  const storage = getStorage(app);
  const functions = getFunctions(app, FUNCTIONS_REGION);

  if (useEmulators) {
    connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
    connectFirestoreEmulator(db, '127.0.0.1', 8080);
    connectStorageEmulator(storage, '127.0.0.1', 9199);
    connectFunctionsEmulator(functions, '127.0.0.1', 5001);
  }
  cached = { app, auth, db, storage, functions };
  return cached;
}
