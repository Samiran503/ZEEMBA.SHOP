import { getAnalytics, isSupported, logEvent, type Analytics } from 'firebase/analytics';
import { firebase, isFirebaseConfigured } from './firebase';

/** Event names used across the site. These feed Firebase Analytics (GA4); first-party aggregates come in Phase 11. */
export const EVENTS = {
  pageView: 'page_view', productView: 'view_item', categoryView: 'view_item_list', search: 'search',
  addToCart: 'add_to_cart', removeFromCart: 'remove_from_cart', wishlistAdd: 'add_to_wishlist',
  beginCheckout: 'begin_checkout', purchase: 'purchase', signUp: 'sign_up', login: 'login',
  couponUsed: 'coupon_used',
  // WhatsApp BUTTON CLICKS only. These are not confirmed conversations and not sales.
  whatsappClick: 'whatsapp_click',
  productWhatsappClick: 'product_whatsapp_click',
  customOrderWhatsappClick: 'custom_order_whatsapp_click',
  photoFrameWhatsappClick: 'photo_frame_whatsapp_click',
  checkoutWhatsappClick: 'checkout_whatsapp_click',
} as const;

let instance: Promise<Analytics | null> | null = null;

function analytics(): Promise<Analytics | null> {
  if (!instance) {
    instance = (async () => {
      if (!isFirebaseConfigured || !import.meta.env.VITE_FIREBASE_MEASUREMENT_ID) return null;
      if (!(await isSupported())) return null;           // blocked by browser/ad-blocker or unsupported env
      return getAnalytics(firebase().app);
    })().catch(() => null);
  }
  return instance;
}

/** Fire-and-forget. Analytics must never break the UI. */
export function track(event: string, params?: Record<string, string | number | boolean | undefined>): void {
  void analytics().then((a) => { if (a) logEvent(a, event, params); }).catch(() => undefined);
}
