import { WHATSAPP_NUMBER_INTL } from '@/config/site';
import { EVENTS, track } from './analytics';

export type WhatsAppContext = 'general' | 'product' | 'custom_order' | 'photo_frame' | 'checkout';

export interface WhatsAppData {
  productName?: string;
  productId?: string;
  sku?: string;
  customization?: string;     // free text typed by the customer
}

// Control characters and over-long user text are removed so the link stays safe and valid.
const clean = (s: string | undefined, max = 300) =>
  (s ?? '').replace(/[\u0000-\u001F\u007F]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

export function buildWhatsAppMessage(ctx: WhatsAppContext, d: WhatsAppData = {}): string {
  const name = clean(d.productName, 120);
  const lines: string[] = [];
  switch (ctx) {
    case 'product':
      lines.push(`Hi ZEEMBA, mujhe ${name || 'ek product'} ke baare mein order karna hai. Mujhe customization details bhi chahiye.`);
      if (name) lines.push(`Product: ${name}`);
      if (d.productId) lines.push(`Product ID: ${clean(d.productId, 60)}`);
      if (d.sku) lines.push(`SKU: ${clean(d.sku, 60)}`);
      if (d.customization) lines.push(`Customization: ${clean(d.customization)}`);
      break;
    case 'photo_frame':
      lines.push(`Hi ZEEMBA, mujhe ${name || 'photo frame'} customize karwana hai. Please mujhe size, photo aur customization options ke baare mein batayein.`);
      if (d.productId) lines.push(`Product ID: ${clean(d.productId, 60)}`);
      if (d.sku) lines.push(`SKU: ${clean(d.sku, 60)}`);
      if (d.customization) lines.push(`Customization: ${clean(d.customization)}`);
      break;
    case 'custom_order':
      lines.push('Hi ZEEMBA, mujhe ek custom handmade product order karna hai. Please mujhe details batayein.');
      break;
    case 'checkout':
      lines.push('Hi ZEEMBA, I need some help regarding my order/checkout. Could you please assist me?');
      break;
    default:
      lines.push('Hi ZEEMBA, I would like to know more about your handmade products.');
  }
  return lines.join('\n');
}

export function whatsappUrl(ctx: WhatsAppContext, d?: WhatsAppData): string {
  return `https://wa.me/${WHATSAPP_NUMBER_INTL}?text=${encodeURIComponent(buildWhatsAppMessage(ctx, d))}`;
}

const SPECIFIC_EVENT: Record<WhatsAppContext, string | null> = {
  general: null,
  product: EVENTS.productWhatsappClick,
  custom_order: EVENTS.customOrderWhatsappClick,
  photo_frame: EVENTS.photoFrameWhatsappClick,
  checkout: EVENTS.checkoutWhatsappClick,
};

/**
 * Records a WhatsApp BUTTON CLICK. Every click sends `whatsapp_click` (use it for totals) and,
 * where applicable, one context event. Dashboards must not add them together.
 */
export function trackWhatsAppClick(ctx: WhatsAppContext, d?: WhatsAppData): void {
  const params = { context: ctx, product_id: d?.productId, sku: d?.sku };
  track(EVENTS.whatsappClick, params);
  const specific = SPECIFIC_EVENT[ctx];
  if (specific) track(specific, params);
}
