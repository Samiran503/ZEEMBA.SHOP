/** Phase 1 placeholder. Secure sign-in + RBAC gate lands in Phase 7; dashboard in Phase 8.
 *  Note: no admin authorization lives in the client. Every action is re-checked by Security Rules / Cloud Functions. */
export function AdminApp() {
  return (
    <main className="mx-auto max-w-xl px-5 py-10">
      <h1 className="text-3xl">ZEEMBA Admin</h1>
      <p className="mt-2 text-ink/70">Admin sign-in will be available after Phase 7.</p>
    </main>
  );
}
