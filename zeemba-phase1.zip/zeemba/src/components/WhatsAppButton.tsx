import type { ReactNode } from 'react';
import { trackWhatsAppClick, whatsappUrl, type WhatsAppContext, type WhatsAppData } from '@/lib/whatsapp';

interface Props { context: WhatsAppContext; data?: WhatsAppData; children: ReactNode; className?: string }

/** A real link (works without JS, long-press to copy, accessible) that also records the click. */
export function WhatsAppButton({ context, data, children, className = '' }: Props) {
  return (
    <a
      href={whatsappUrl(context, data)}
      target="_blank"
      rel="noopener noreferrer"
      onClick={() => trackWhatsAppClick(context, data)}
      className={`inline-flex min-h-[48px] items-center justify-center rounded-md bg-sage px-5 py-3 font-semibold text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo ${className}`}
    >
      {children}
    </a>
  );
}
