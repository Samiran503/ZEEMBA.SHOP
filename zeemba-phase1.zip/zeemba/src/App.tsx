import { SITE, WHATSAPP_NUMBER_DISPLAY } from './config/site';
import { isFirebaseConfigured } from './lib/firebase';
import { WhatsAppButton } from './components/WhatsAppButton';

/** Phase 1 shell: proves build, env wiring and WhatsApp utility. The full storefront arrives in Phase 2. */
export function App() {
  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-6 px-5 py-10">
      <h1 className="text-5xl leading-tight">{SITE.name}</h1>
      <p className="text-lg text-indigo-soft">{SITE.tagline}</p>
      <p className="max-w-prose">{SITE.heroText}</p>

      {!isFirebaseConfigured && (
        <p role="status" className="border-l-4 border-marigold bg-marigold/10 p-4 text-sm">
          Firebase is not configured yet. Copy <code>.env.example</code> to <code>.env</code> and add your project values.
        </p>
      )}

      <div>
        <WhatsAppButton context="general">Chat on WhatsApp</WhatsAppButton>
        <p className="mt-2 text-sm text-ink/70">{WHATSAPP_NUMBER_DISPLAY}</p>
      </div>
    </main>
  );
}
