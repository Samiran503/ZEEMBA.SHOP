export const SITE = {
  name: 'ZEEMBA',
  tagline: 'Handmade with Love',
  heroText: 'Thoughtfully crafted gifts and personalized creations made especially for you.',
  url: 'https://zeemba.com',
  currency: 'INR',
  locale: 'en-IN',
} as const;

/** Official ZEEMBA WhatsApp number. Single source of truth for the whole site. */
export const WHATSAPP_NUMBER_INTL = '917896160761';          // wa.me format: country code + number, digits only
export const WHATSAPP_NUMBER_DISPLAY = '+91 78961 60761';    // human-readable
