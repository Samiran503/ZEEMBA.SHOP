import type { Timestamp } from 'firebase/firestore';

/** All money is stored as integer paise (₹1 = 100) to avoid floating-point errors. */
export type Paise = number;

export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'STAFF';

export interface UserProfile {
  displayName?: string; email: string; phone?: string;
  preferences?: Record<string, unknown>;
  createdAt: Timestamp; updatedAt: Timestamp;
}
export interface Address {
  label?: string; fullName: string; phone: string; line1: string; line2?: string;
  city: string; state: string; pincode: string; landmark?: string; isDefault?: boolean;
}

export interface Category {
  id: string; name: string; slug: string; sortOrder: number;
  isActive: boolean; isArchived: boolean; imageUrl?: string;
}

export interface PhotoFrameSpec {
  frameSizes: string[]; materials: string[]; colours: string[];
  numberOfPhotos: number; orientation: 'PORTRAIT' | 'LANDSCAPE' | 'SQUARE' | 'ANY';
  allowsCustomText: boolean; allowsCustomName: boolean; allowsCustomDate: boolean; allowsCustomMessage: boolean;
  photoUpload: 'REQUIRED' | 'OPTIONAL' | 'NONE';
  designInstructions?: string; previewImageUrl?: string;
}

export type StockStatus = 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK';

export interface Product {
  id: string; sku: string; name: string; slug: string;
  categoryId: string; subcategory?: string;
  shortDescription: string; description: string;
  images: { path: string; url: string; alt: string }[];
  price: Paise; mrp: Paise; discountPercent: number;
  stockStatus: StockStatus;               // public, denormalised. Exact quantities live in /inventory (staff only).
  materials?: string[]; dimensions?: string; weight?: string; colour?: string[]; size?: string[];
  tags: string[]; handmadeDetails?: string;
  isCustomizable: boolean; photoFrame?: PhotoFrameSpec;
  isFeatured: boolean; isNewArrival: boolean; isBestSeller: boolean;
  isActive: boolean; isArchived: boolean;
  salesCount: number; ratingAverage?: number; ratingCount?: number;
  createdAt: Timestamp; updatedAt: Timestamp;
}

export interface InventoryRecord {
  productId: string; quantity: number; reserved: number; lowStockThreshold: number; updatedAt: Timestamp;
} // available = quantity - reserved
export interface InventoryHistoryEntry {
  delta: number; reason: string; before: number; after: number; byUid: string; orderId?: string; createdAt: Timestamp;
}

export interface CustomizationData {
  uploadPaths: string[];                  // Storage paths under orderUploads/{uid}/... (private)
  name?: string; text?: string; date?: string; message?: string;
  options?: Record<string, string>; instructions?: string;
}
export interface CartItem {
  productId: string; quantity: number; customization?: CustomizationData;
}
export interface Cart { items: CartItem[]; couponCode?: string; updatedAt: Timestamp }
export interface Wishlist { productIds: string[]; updatedAt: Timestamp }

export type OrderStatus =
  | 'NEW' | 'CONFIRMED' | 'PROCESSING' | 'IN_PRODUCTION' | 'PACKED'
  | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED' | 'RETURN_REQUESTED' | 'REFUNDED';
export type PaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED';

export interface OrderItemSnapshot {
  productId: string; sku: string; name: string; image?: string;
  unitPrice: Paise; mrp: Paise; quantity: number; lineTotal: Paise;
  customization?: CustomizationData;
}
export interface Order {
  id: string; orderNumber: string; customerId: string;
  customer: { name: string; phone: string; email: string };
  items: OrderItemSnapshot[];             // price/product snapshot: history never depends on current catalog
  subtotal: Paise; discount: Paise; shipping: Paise; total: Paise; couponCode?: string;
  paymentStatus: PaymentStatus;
  payment?: { provider: 'RAZORPAY'; providerOrderId?: string; providerPaymentId?: string }; // ids only, never card data
  status: OrderStatus;
  shippingAddress: Address & { deliveryInstructions?: string };
  tracking?: { carrier?: string; trackingNumber?: string; url?: string };
  internalNotes?: string;
  createdAt: Timestamp; updatedAt: Timestamp;
}

export type CustomOrderStatus =
  | 'NEW' | 'REVIEWING' | 'QUOTE_SENT' | 'CUSTOMER_CONFIRMED' | 'IN_PRODUCTION' | 'READY' | 'COMPLETED' | 'CANCELLED';
export interface CustomOrder {
  id: string; customerId: string; status: CustomOrderStatus;
  productType: string; name: string; phone: string; email: string;
  preferredDesign?: string; colourPreference?: string; size?: string; budget?: string; instructions?: string;
  referenceImagePaths: string[]; customerPhotoPaths: string[];
  internalNotes?: string; quoteAmount?: Paise;
  createdAt: Timestamp; updatedAt: Timestamp;
}

export type ReviewStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'HIDDEN';
export interface Review {
  id: string; productId: string; orderId: string; customerId: string; displayName: string;
  rating: 1 | 2 | 3 | 4 | 5; text: string; imagePath?: string; verifiedPurchase: true;
  status: ReviewStatus; createdAt: Timestamp;
}

export interface Coupon {
  code: string; type: 'PERCENT' | 'FIXED'; value: number; minOrderValue?: Paise; maxDiscount?: Paise;
  productIds?: string[]; categoryIds?: string[]; startsAt: Timestamp; endsAt: Timestamp;
  usageLimit?: number; perCustomerLimit?: number; usedCount: number; isActive: boolean;
}

export interface AdminActivityLog {
  adminUid: string; role: Role; action: string; target: { type: string; id: string } | null;
  metadata: Record<string, unknown>; createdAt: Timestamp;
}
