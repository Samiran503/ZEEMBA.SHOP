import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, describe, it } from 'vitest';
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { ref, uploadBytes, getBytes } from 'firebase/storage';

let env: RulesTestEnvironment;
const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

beforeAll(async () => {
  env = await initializeTestEnvironment({
    projectId: 'zeemba-rules-test',
    storage: { rules: readFileSync('storage.rules', 'utf8'), host: '127.0.0.1', port: 9199 },
  });
});
afterAll(async () => { await env.cleanup(); });

const st = (uid: string, role?: string) => env.authenticatedContext(uid, role ? { role } : {}).storage();
const path = (uid: string, name = 'a1b2c3d4e5.png') => `orderUploads/${uid}/upload_0001/${name}`;
const meta = { contentType: 'image/png' };

describe('private customer uploads', () => {
  it('owner can upload a valid image', async () => {
    await assertSucceeds(uploadBytes(ref(st('alice'), path('alice')), png, meta));
  });
  it('cannot upload into someone else\'s folder or when signed out', async () => {
    await assertFails(uploadBytes(ref(st('mallory'), path('alice')), png, meta));
    await assertFails(uploadBytes(ref(env.unauthenticatedContext().storage(), path('alice')), png, meta));
  });
  it('rejects non-image types, bad filenames and oversize files', async () => {
    await assertFails(uploadBytes(ref(st('alice'), path('alice', 'a1b2c3d4e5.png')), png, { contentType: 'text/html' }));
    await assertFails(uploadBytes(ref(st('alice'), path('alice', '../evil.png')), png, meta));
    await assertFails(uploadBytes(ref(st('alice'), path('alice', 'a1b2c3d4e5.html')), png, meta));
    await assertFails(uploadBytes(ref(st('alice'), path('alice', 'b1b2c3d4e5.png')), new Uint8Array(11 * 1024 * 1024), meta));
  });
  it('is readable by owner and staff only', async () => {
    await env.withSecurityRulesDisabled(async (ctx) => { await uploadBytes(ref(ctx.storage(), path('alice', 'seeded0001.png')), png, meta); });
    const p = path('alice', 'seeded0001.png');
    await assertSucceeds(getBytes(ref(st('alice'), p)));
    await assertSucceeds(getBytes(ref(st('stf', 'STAFF'), p)));
    await assertFails(getBytes(ref(st('mallory'), p)));
    await assertFails(getBytes(ref(env.unauthenticatedContext().storage(), p)));
  });
  it('cannot be overwritten or deleted by the customer', async () => {
    await assertFails(uploadBytes(ref(st('alice'), path('alice', 'seeded0001.png')), png, meta));
  });
});

describe('public assets', () => {
  it('only ADMIN/SUPER_ADMIN can write product images; STAFF and customers cannot', async () => {
    const p = 'products/p1/a1b2c3d4e5.png';
    await assertSucceeds(uploadBytes(ref(st('adm', 'ADMIN'), p), png, meta));
    await assertFails(uploadBytes(ref(st('stf', 'STAFF'), 'products/p1/b1b2c3d4e5.png'), png, meta));
    await assertFails(uploadBytes(ref(st('alice'), 'products/p1/c1b2c3d4e5.png'), png, meta));
  });
  it('arbitrary paths are closed', async () => {
    await assertFails(uploadBytes(ref(st('adm', 'SUPER_ADMIN'), 'random/file.png'), png, meta));
  });
});
