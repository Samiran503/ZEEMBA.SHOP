import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp, collection, getDocs, query, where, deleteDoc } from 'firebase/firestore';

let env: RulesTestEnvironment;

beforeAll(async () => {
  env = await initializeTestEnvironment({
    projectId: 'zeemba-rules-test',
    firestore: { rules: readFileSync('firestore.rules', 'utf8'), host: '127.0.0.1', port: 8080 },
  });
});
afterAll(async () => { await env.cleanup(); });

beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await setDoc(doc(db, 'settings/rolePermissions'), {
      ADMIN: ['products.read', 'orders.read', 'coupons.read', 'logs.read'],
      STAFF: ['orders.read'],
    });
    await setDoc(doc(db, 'products/live'), { name: 'Frame', isActive: true, isArchived: false });
    await setDoc(doc(db, 'products/hidden'), { name: 'Draft', isActive: false, isArchived: false });
    await setDoc(doc(db, 'products/old'), { name: 'Old', isActive: true, isArchived: true });
    await setDoc(doc(db, 'orders/o1'), { customerId: 'alice', total: 49900 });
    await setDoc(doc(db, 'orders/o2'), { customerId: 'bob', total: 19900 });
    await setDoc(doc(db, 'coupons/WELCOME10'), { code: 'WELCOME10' });
    await setDoc(doc(db, 'adminActivityLogs/l1'), { action: 'X' });
    await setDoc(doc(db, 'settings/security'), { bootstrapped: true });
    await setDoc(doc(db, 'users/alice'), { email: 'alice@x.com', displayName: 'Alice', createdAt: new Date(), updatedAt: new Date() });
  });
});

const anon = () => env.unauthenticatedContext().firestore();
const user = (uid: string) => env.authenticatedContext(uid, { email: `${uid}@x.com` }).firestore();
const withRole = (uid: string, role: string) => env.authenticatedContext(uid, { role, email: `${uid}@x.com` }).firestore();

describe('catalog', () => {
  it('public can read active, non-archived products only', async () => {
    await assertSucceeds(getDoc(doc(anon(), 'products/live')));
    await assertFails(getDoc(doc(anon(), 'products/hidden')));
    await assertFails(getDoc(doc(anon(), 'products/old')));
  });
  it('nobody can write products from the client, not even SUPER_ADMIN', async () => {
    await assertFails(setDoc(doc(anon(), 'products/new'), { name: 'x' }));
    await assertFails(setDoc(doc(user('alice'), 'products/new'), { name: 'x' }));
    await assertFails(setDoc(doc(withRole('root', 'SUPER_ADMIN'), 'products/new'), { name: 'x' }));
  });
  it('permitted staff can read hidden products', async () => {
    await assertSucceeds(getDoc(doc(withRole('adm', 'ADMIN'), 'products/hidden')));
    await assertFails(getDoc(doc(withRole('stf', 'STAFF'), 'products/hidden')));
  });
});

describe('orders & customer data isolation', () => {
  it('customer reads own order only', async () => {
    await assertSucceeds(getDoc(doc(user('alice'), 'orders/o1')));
    await assertFails(getDoc(doc(user('alice'), 'orders/o2')));
    await assertFails(getDoc(doc(anon(), 'orders/o1')));
  });
  it('unfiltered order list is rejected, filtered list works', async () => {
    await assertFails(getDocs(collection(user('alice'), 'orders')));
    await assertSucceeds(getDocs(query(collection(user('alice'), 'orders'), where('customerId', '==', 'alice'))));
  });
  it('customers cannot create, edit or delete orders', async () => {
    await assertFails(setDoc(doc(user('alice'), 'orders/o9'), { customerId: 'alice', total: 1 }));
    await assertFails(updateDoc(doc(user('alice'), 'orders/o1'), { total: 1 }));
    await assertFails(deleteDoc(doc(user('alice'), 'orders/o1')));
  });
  it('staff with orders.read can read any order', async () => {
    await assertSucceeds(getDoc(doc(withRole('stf', 'STAFF'), 'orders/o2')));
  });
});

describe('roles & permissions', () => {
  it('STAFF lacks coupons.read, ADMIN has it, anon/customers never', async () => {
    await assertFails(getDoc(doc(withRole('stf', 'STAFF'), 'coupons/WELCOME10')));
    await assertSucceeds(getDoc(doc(withRole('adm', 'ADMIN'), 'coupons/WELCOME10')));
    await assertFails(getDoc(doc(user('alice'), 'coupons/WELCOME10')));
  });
  it('audit logs are readable only with logs.read and never writable', async () => {
    await assertFails(getDoc(doc(withRole('stf', 'STAFF'), 'adminActivityLogs/l1')));
    await assertSucceeds(getDoc(doc(withRole('adm', 'ADMIN'), 'adminActivityLogs/l1')));
    await assertFails(setDoc(doc(withRole('root', 'SUPER_ADMIN'), 'adminActivityLogs/l2'), { action: 'forged' }));
  });
  it('a forged role value is not honoured', async () => {
    await assertFails(getDoc(doc(withRole('x', 'OWNER'), 'coupons/WELCOME10')));
  });
  it('bootstrap lock and role registry are not client-readable/writable', async () => {
    await assertFails(getDoc(doc(withRole('root', 'SUPER_ADMIN'), 'settings/security')));
    await assertFails(setDoc(doc(withRole('root', 'SUPER_ADMIN'), 'staff/root'), { role: 'SUPER_ADMIN', active: true }));
  });
});

describe('user profile', () => {
  it('owner can read, others cannot', async () => {
    await assertSucceeds(getDoc(doc(user('alice'), 'users/alice')));
    await assertFails(getDoc(doc(user('bob'), 'users/alice')));
  });
  it('cannot self-assign role or arbitrary fields', async () => {
    await assertFails(updateDoc(doc(user('alice'), 'users/alice'), { role: 'SUPER_ADMIN', updatedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(user('bob'), 'users/bob'), { email: 'bob@x.com', role: 'ADMIN', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
  });
  it('can create a valid profile for self only', async () => {
    await assertSucceeds(setDoc(doc(user('bob'), 'users/bob'), { email: 'bob@x.com', displayName: 'Bob', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(user('bob'), 'users/carol'), { email: 'bob@x.com', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
  });
});

describe('cart & wishlist', () => {
  it('owner can save items but cannot store totals', async () => {
    const ok = { items: [{ productId: 'live', quantity: 1 }], updatedAt: serverTimestamp() };
    await assertSucceeds(setDoc(doc(user('alice'), 'carts/alice'), ok));
    await assertFails(setDoc(doc(user('alice'), 'carts/alice'), { ...ok, total: 1 }));
    await assertFails(setDoc(doc(user('bob'), 'carts/alice'), ok));
  });
  it('wishlist is private to owner', async () => {
    await assertSucceeds(setDoc(doc(user('alice'), 'wishlists/alice'), { productIds: ['live'], updatedAt: serverTimestamp() }));
    await assertFails(getDoc(doc(user('bob'), 'wishlists/alice')));
  });
});

describe('default deny', () => {
  it('unknown collections are closed', async () => {
    await assertFails(getDoc(doc(withRole('root', 'SUPER_ADMIN'), 'whatever/doc')));
    await assertFails(setDoc(doc(anon(), 'rateLimits/x'), { count: 0 }));
  });
});
